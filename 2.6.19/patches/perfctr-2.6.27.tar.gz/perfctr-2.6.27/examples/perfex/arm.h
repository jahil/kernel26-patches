/* $Id: arm.h,v 1.1.2.1 2007/02/11 20:14:31 mikpe Exp $
 * ARM-specific declarations.
 *
 * Copyright (C) 2005-2007  Mikael Pettersson
 */

#define ARCH_LONG_OPTIONS	/*empty*/
