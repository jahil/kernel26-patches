/*************************************
 * File		: ktau_misc.h
 * Version	: $Id: ktau_misc.h,v 1.1 2006/11/12 00:26:28 anataraj Exp $
 ************************************/
#ifndef _KTAU_MISC_H_
#define _KTAU_MISC_H_

int ktau_leftmost1( unsigned int val);

#endif /*_KTAU_MISC_H_*/
