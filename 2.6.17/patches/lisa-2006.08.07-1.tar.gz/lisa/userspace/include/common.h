#ifndef __COMMON_H
#define __COMMON_H

#define MAX_HOSTNAME 32

#define PAGER_PATH "/bin/more"
#ifndef FILTER_PATH
#define FILTER_PATH "/bin/filter"
#endif

#define PROCNETDEV_PATH "/proc/net/dev"
#define LMS_VIRT_PREFIX "vlan"

#endif
