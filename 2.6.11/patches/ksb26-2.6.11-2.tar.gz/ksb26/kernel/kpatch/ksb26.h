/*****************************************************************************/
/* Kernel SOCKS Bouncer (Kernel Patch) for 2.6.x kernels [KSB26]             */
/* (c) 2004-2005 Paolo Ardoino <ardoino.gnu@disi.unige.it>                   */
/*****************************************************************************/
/*									     */
/* This program is free software; you can redistribute it and/or modify	     */
/* it under the terms of the GNU General Public License as published by	     */
/* the Free Software Foundation; either version 2 of the License, or	     */
/* (at your option) any later version.					     */
/* This program is distributed in the hope that it will be useful,	     */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of	     */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the	     */
/* GNU General Public License for more details.				     */
/*									     */
/* You should have received a copy of the GNU General Public License	     */
/* along with this program; if not, write to the Free Software		     */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */
/*****************************************************************************/

#include <linux/in.h>
#include <linux/inet.h>
#include <linux/byteorder/generic.h>
#include <linux/slab.h>
#include <linux/preempt.h>
#include <linux/fcntl.h>
#include <asm/semaphore.h>

#include "ksb26_h.h"

#define DEBUG 1 

#define KSB26_SSEND(fd, buf, blen) do { mm_segment_t oldfs; oldfs = get_fs(); \
	set_fs(get_ds()); sys_send(fd, buf, blen, 0); set_fs(oldfs); } while(0)
#define KSB26_SRECV(fd, buf, maxlen, err) do { mm_segment_t oldfs; err = 0; \
	oldfs = get_fs(); set_fs(get_ds()); memset(buf, '\0', maxlen); \
	err = sys_recv(fd, buf, maxlen, 0); set_fs(oldfs); } while(0)
#define KSB26_S4HSOK(buf, err) do { if(buf[1] != 0x5A) { err = -1; kfree(buf); \
	return -1; } } while(0)
#define KSB26_S5HSOK(buf, err) do { if(buf[0] != 0x05 || buf[1] != 0x00) { err = -1; \
	kfree(buf); return -1; } } while(0)
#define KSB26_SOCKS4HS "\004\001%c%c%c%c%c%c"
#define KSB26_SOCKS5HS "\x05\x01%c"
#define KSB26_SOCKS5RQ "\x05\x01%c\x03%c%s%c%c"
#define KSB26_DOWN_LISTSEM do { down_interruptible(&ksb26_cntsem); ksb26_connect_cnt++; \
	if(ksb26_connect_cnt == 1) down_interruptible(&ksb26_listsem); up(&ksb26_cntsem); } while(0)
#define KSB26_UP_LISTSEM do { down_interruptible(&ksb26_cntsem); ksb26_connect_cnt--; \
	if(ksb26_connect_cnt == 0) up(&ksb26_listsem); up(&ksb26_cntsem); } while(0)

asmlinkage long sys_connect_orig(int fd, struct sockaddr __user *uservaddr, int addrlen);

char ksb26;
unsigned int ksb26_nsocks;
unsigned int ksb26_nbhddrs;
struct ksb26_host ksb26_slh;
struct ksb26_host ksb26_bhlh;
struct semaphore ksb26_listsem;
struct semaphore ksb26_cntsem;
int ksb26_connect_cnt; 
int ksb26_maxsocks;

static char *ksb26_ntoa(unsigned long saddr)
{
	static char buff[18];
	char *p;

	p = (char *)&saddr;
	sprintf(buff, "%d.%d.%d.%d", (*p & 255), (*(p + 1) & 255), (*(p + 2) & 255), \
			(*(p + 3) & 255));
	return buff;
}                                                        

static int ksb26_2bounce(unsigned long naddr)
{
	struct ksb26_host *ksb26_bhlaux = ksb26_bhlh.next;

	for(; ksb26_bhlaux != &ksb26_bhlh; ksb26_bhlaux = ksb26_bhlaux->next)
		if(ksb26_bhlaux->naddr == naddr) 
			return 1;
	return 0;
}

static int ksb26_socks4hs(int fd, char *dhost, int dport)
{
	int err = -1;
	int buflen = 0;
	char *buf = NULL;

	buf = (char *)kmalloc(PAGE_SIZE, GFP_KERNEL);
	
	buflen = snprintf(buf, PAGE_SIZE, KSB26_SOCKS4HS, (dport >> 8) & 0xFF, dport & 0xFF, (char)dhost[0], \
			(char)dhost[1], (char)dhost[2], (char)dhost[3]);
	buf[8] = 0;
	KSB26_SSEND(fd, buf, 9);
	KSB26_SRECV(fd, buf, PAGE_SIZE, err);
	KSB26_S4HSOK(buf, err);
	kfree(buf);
	return err;
}

static int ksb26_socks5hs(int fd, char *dhost, int dport)
{
	int err = -1;
	int buflen = 0;
	char *buf = NULL;
  
	buf = (char *)kmalloc(PAGE_SIZE, GFP_KERNEL);
	buflen = snprintf(buf, PAGE_SIZE, KSB26_SOCKS5HS, 0);
	KSB26_SSEND(fd, buf, buflen);
	KSB26_SRECV(fd, buf, PAGE_SIZE, err);
	KSB26_S5HSOK(buf, err);
  	buflen = snprintf(buf, PAGE_SIZE, KSB26_SOCKS5RQ, 0, strlen(dhost), dhost, (dport >> 8) & 0xFF, dport & 0xFF);
	KSB26_SSEND(fd, buf, buflen);
	KSB26_SRECV(fd, buf, PAGE_SIZE, err);
	KSB26_S5HSOK(buf, err);
	kfree(buf);
	return err;
}

static int ksb26_1st_socks(int fd, struct sockaddr __user **uservaddr, int addrlen, struct ksb26_host **ksb26_slaux)
{
	struct sockaddr_in *ksin = (struct sockaddr_in *)*uservaddr;
	int err = -1;
	mm_segment_t oldfs;
	struct ksb26_host *ksb26_aux;
	
	for(ksb26_aux = ksb26_slh.next; ksb26_aux != &ksb26_slh && err != 0; ksb26_aux = ksb26_aux->next) {
		if(ksb26_aux->wrk == 1) {
#ifdef DEBUG
			printk("[%s] Trying [1] %s:%d SOCKS v%d.\n", MODNAME, ksb26_aux->ip, ksb26_aux->port, ksb26_aux->type);
#endif
			oldfs = get_fs();
			set_fs(get_ds());
			ksin->sin_addr.s_addr = ksb26_aux->naddr;
			ksin->sin_port = ksb26_aux->nport;
			set_fs(oldfs);
			err = sys_connect_orig(fd, *uservaddr, addrlen);
		}
	}
	if(err == 0) {
		*ksb26_slaux = ksb26_aux->prev;
		printk("[%s] Connected to %s:%d [1] SOCKS v%d.\n", MODNAME, ksb26_aux->prev->ip, ksb26_aux->prev->port, \
				ksb26_aux->prev->type);
	}
	return err;
}

static int ksb26_socks_chain(int fd, int *scnt, struct ksb26_host **ksb26_slaux)
{
	struct ksb26_host *ksb26_aux = *ksb26_slaux;
	int err = 1;
	
	for(*scnt = 1, ksb26_aux = ksb26_aux->next; ksb26_aux != &ksb26_slh && *scnt < ksb26_maxsocks ; ksb26_aux = ksb26_aux->next) {
		if(ksb26_aux->wrk == 1) {
#ifdef DEBUG
			printk("[%s] Trying [%d] %s:%d SOCKS v%d.\n", MODNAME, (*scnt) + 1, ksb26_aux->ip, ksb26_aux->port, ksb26_aux->type);
#endif
			if(ksb26_aux->type == 5) {
				if((err = ksb26_socks5hs(fd, ksb26_aux->ip, ksb26_aux->port)) > 0) {
					(*scnt)++;
					printk("[%s] Connected to %s:%d [%d] SOCKS v5.\n", MODNAME, ksb26_aux->ip, ksb26_aux->port, *scnt);
				} else 
					break;
			} else {
				if(ksb26_aux->type == 4) {
					if((err = ksb26_socks4hs(fd, ksb26_aux->ipc, ksb26_aux->port)) > 0) {
						(*scnt)++;
						printk("[%s] Connected to %s:%d [%d] SOCKS v4.\n", MODNAME, ksb26_aux->ip, ksb26_aux->port, *scnt);
					} else
						break;
				}
			}
		}
	}
	*ksb26_slaux = ksb26_aux->prev;
	return err;
}

asmlinkage long sys_connect_ksb26(int fd, struct sockaddr __user *uservaddr, int addrlen)
{
	mm_segment_t oldfs;
	struct sockaddr_in *ksin = (struct sockaddr_in *)uservaddr;
	struct ksb26_host *ksb26_slaux;
	unsigned long int daddr;
	unsigned short int dport;
	int err = 0, scnt = 1;
	int sock_flags_old;
	
	KSB26_DOWN_LISTSEM;	
	oldfs = get_fs();
	set_fs(get_ds());
	if (ksb26_2bounce(ksin->sin_addr.s_addr) == 1) {
#ifdef DEBUG
		printk("[%s] SYS_CONNECT_KSB26 : localhost -> %s:%d\n", MODNAME, ksb26_ntoa(ksin->sin_addr.s_addr), ntohs(ksin->sin_port));
#endif
		daddr = ksin->sin_addr.s_addr;
		dport = ksin->sin_port;
		if((sock_flags_old = sys_fcntl(fd, F_GETFL, 0)) < 0) {
			printk("[%s] Cannot read socket flags.\n", MODNAME);
			set_fs(oldfs);
			KSB26_UP_LISTSEM;
			return -1;
		}

		if(sock_flags_old != 2)
			sys_fcntl(fd, F_SETFL, 2);
		set_fs(oldfs);

		if((err = ksb26_1st_socks(fd, &uservaddr, addrlen, &ksb26_slaux)) != 0) {
			KSB26_UP_LISTSEM;
			return err;
		}
		
		if(ksb26_socks_chain(fd, &scnt, &ksb26_slaux) <= 0) {	
			ksb26_slaux->wrk = 0;
			KSB26_UP_LISTSEM;
			printk("[%s] Please retry.\n", MODNAME);
			return -1;
		}

		if(scnt < ksb26_maxsocks) {
			KSB26_UP_LISTSEM;
			printk("[%s] Too few working SOCKS in list.\n", MODNAME);
			return err;
		}
		if(ksb26_slaux->type == 5)
			err = ksb26_socks5hs(fd, ksb26_ntoa(daddr), ntohs(dport));
		else
			if(ksb26_slaux->type == 4)
				err = ksb26_socks4hs(fd, ksb26_ntoa(daddr), ntohs(dport));
		if(err <= 0) {
			ksb26_slaux->wrk = 0;
			KSB26_UP_LISTSEM;
			printk("[%s] Connection refused to destination host [%s:%d].\n", MODNAME, ksb26_ntoa(daddr), ntohs(dport));
			return -ECONNREFUSED;
		}
		printk("[%s] Connected to destination host [%s:%d].\n", MODNAME, ksb26_ntoa(daddr), ntohs(dport));
		oldfs = get_fs();
		set_fs(get_ds());
		if(sock_flags_old != 2)
			sys_fcntl(fd, F_SETFL, sock_flags_old);
		set_fs(oldfs);
	} else  {
		set_fs(oldfs);
		err = sys_connect_orig(fd, uservaddr, addrlen);
	}
	KSB26_UP_LISTSEM;
	return err;
}

EXPORT_SYMBOL(ksb26);
EXPORT_SYMBOL(ksb26_nsocks);
EXPORT_SYMBOL(ksb26_connect_cnt);
EXPORT_SYMBOL(ksb26_slh);
EXPORT_SYMBOL(ksb26_bhlh);
EXPORT_SYMBOL(ksb26_listsem);
EXPORT_SYMBOL(ksb26_cntsem);
EXPORT_SYMBOL(ksb26_maxsocks);
