#***************************************************************************#
# Kernel SOCKS Bouncer (Kernel Patch) for 2.6.x kernels [KSB26]             #
# (c) 2004-2005 Paolo Ardoino <ardoino.gnu@disi.unige.it>                   #
#***************************************************************************#
#									    #
# This program is free software; you can redistribute it and/or modify	    #
# it under the terms of the GNU General Public License as published by	    # 
# the Free Software Foundation; either version 2 of the License, or	    # 
# (at your option) any later version.					    #
# This program is distributed in the hope that it will be useful,	    #
# but WITHOUT ANY WARRANTY; without even the implied warranty of	    #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             #
# GNU General Public License for more details.				    #
#									    #
# You should have received a copy of the GNU General Public License	    #
# along with this program; if not, write to the Free Software		    #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA #
#***************************************************************************#


installer_version=0.0.2
kernel_dir=/usr/src/linux
bin_dir=/usr/bin

echo "Kernel Socks Bouncer for 2.6.x kernels Installer v$installer_version"
echo ""

# Checking all components of KSB26
echo "Checking components of KSB26:"
if [ ! -d kernel ] || [ ! user ] ; then
	echo "Cannot find subdirectoryes containing components of KSB26"
	exit -1
fi
echo -n "kernel/ksb26.patch -> "
if [ ! -e kernel/ksb26.patch ] ; then
	echo "not found!"
	exit -1
else
	echo "found!"
fi
echo -n "kernel/ksb26lkm.c -> "
if [ ! -e kernel/lkm/ksb26lkm.c ] ; then
	echo "not found!"
	exit -1
else
	echo "found!"
fi
echo -n "user/ksb26manager -> "
if [ ! -e user/ksb26manager ] ; then
	echo "not found!"
	exit -1
else
	echo "found!"
fi

# Checking Linux kernel source directory
if [ ! -d $kernel_dir ] || [ ! $kernel_dir/net ] || [ ! $kernel_dir/include ]  || [ ! $kernel_dir/kernel ] ; then
	echo "Cannot find Linux Kernel source in $kernel_dir"
	echo "Please edit this script and set 'kernel_dir' to the correct value'"
	exit -1
fi

# Starting installation
echo "Patching Linux kernel source"
cp kernel/ksb26.patch $kernel_dir
if [ ! -e $kernel_dir/ksb26.patch ] ; then
	exit -1
fi
patch -d $kernel_dir -b -p0 < kernel/ksb26.patch
if [ ! -e $kernel_dir/net/ksb26.h ] ; then
	echo "Failed to patch Linux kernel source"
	exit -1
fi
echo "Building kernel/lkm/ksb26lkm.c"
make -C /usr/src/linux/ SUBDIRS=$PWD/kernel/lkm V=1 modules
if [ ! -e kernel/lkm/ksb26lkm.ko ] ; then
	exit -1
fi
echo "Installing kernel/lkm/ksb26lkm.ko"
make -C /usr/src/linux/ SUBDIRS=$PWD/kernel/lkm V=1 modules_install
depmod
echo "Installing user/ksb26manager"
cp user/ksb26manager $bin_dir
if [ ! -e $bin_dir/ksb26manager ] ; then
	exit -1
fi
echo "Done"
echo ""
echo "Now you have to :"
echo "* rebuild your Linux Kernel patched with KSB26 [simply run 'make' command in $kernel_dir directory]"
echo "* modify your boot loader configuration file [read README]"
echo "* reboot"
echo "* read README for informations about the use of KSB26"
